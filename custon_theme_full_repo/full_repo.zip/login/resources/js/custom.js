document.addEventListener("DOMContentLoaded", function () {
    const logo = document.getElementById("company-logo");
    if (logo) {
        logo.addEventListener("click", function () {
            window.location.href = "http://localhost:4200"; // change to your app URL
        });
    }
});
